import pygame
import pygame.camera
from pygame.locals import *
import numpy as np
import matplotlib.pyplot as plt
import time
from PIL import Image



DEVICE = '/dev/video0'
SIZE = (640, 480)
FILENAME = 'capture.png'


def flipimg(x):
    x = np.fliplr(x)
    x = np.rot90(x,k=1,axes=(0,1))
    return x

def snap():
    return flipimg(pygame.surfarray.array3d(camera.get_image()))


pygame.init()
pygame.camera.init()

camera = pygame.camera.Camera(DEVICE, SIZE)
camera.start()

currentRez = (pygame.display.Info().current_w, pygame.display.Info().current_h)
screen = pygame.display.set_mode(currentRez, pygame.SCALED) # print(pygame.display.Info().current_w,pygame.display.Info().current_h) #1920 1080


red   = (200,0,0)
blue  = (0,0,200)
black = (0,0,0)
white = (200,200,200)

radius = 30

x = np.random.randint(0,1920)
y = np.random.randint(0,1080)

capture = True
while capture:
    
    for event in pygame.event.get():
       if event.type == QUIT:
           capture = False
       elif event.type == KEYDOWN:
           if event.key == K_ESCAPE:
               capture = False
           if event.key == K_SPACE:
               
               # pygame.image.save(screen, FILENAME)
               
               Image.fromarray(snap()).save(str(x) + "_" + str(y) + "_" + ".jpeg")
               
               x = np.random.randint(0,1920)
               y = np.random.randint(0,1080)
               
               
    screen.fill((0,0,0))
    pygame.draw.circle(screen,blue,(x,y),radius)
    pygame.draw.circle(screen,white,(x,y),2)
    pygame.display.update() 


    



    # plt.imshow(snap())
    # plt.show()

    
    
    
camera.stop()
pygame.quit()
    
