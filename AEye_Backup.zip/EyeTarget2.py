import pygame

window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

red = (200,0,0)

circleX = 1000
circleY = 1000
radius = 10

active = True

while active:
    
   for event in pygame.event.get():
      if event.type == KEYDOWN:
          if event.key == K_ESCAPE:
              active = False

   pygame.draw.circle(window,red,(circleX,circleY),radius) # DRAW CIRCLE

   pygame.display.update()
