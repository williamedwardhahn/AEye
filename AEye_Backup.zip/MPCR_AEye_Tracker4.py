import pygame
import pygame.camera
from pygame.locals import *
import numpy as np
import matplotlib.pyplot as plt
import time
from PIL import Image

from facenet_pytorch import MTCNN
from PIL import Image
import torch
import cv2
import time
import glob
from tqdm.notebook import tqdm
import numpy as np
import imageio
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from scipy.stats import truncnorm

def plot(x):
    fig, ax = plt.subplots()
    im = ax.imshow(x,cmap='gray')
    ax.axis('off')
    fig.set_size_inches(20, 20)
    plt.show()

device = 'cuda' if torch.cuda.is_available() else 'cpu'


class FastMTCNN(object):
    """Fast MTCNN implementation."""
    
    def __init__(self, stride, resize=1, *args, **kwargs):
        """Constructor for FastMTCNN class.
        
        Arguments:
            stride (int): The detection stride. Faces will be detected every `stride` frames
                and remembered for `stride-1` frames.
        
        Keyword arguments:
            resize (float): Fractional frame scaling. [default: {1}]
            *args: Arguments to pass to the MTCNN constructor. See help(MTCNN).
            **kwargs: Keyword arguments to pass to the MTCNN constructor. See help(MTCNN).
        """
        self.stride = stride
        self.resize = resize
        self.mtcnn = MTCNN(*args, **kwargs)
        
    def __call__(self, frame):
        """Detect faces in frames using strided MTCNN."""
                      
        boxes, probs = self.mtcnn.detect(frame)

        return boxes

fast_mtcnn = FastMTCNN(
    stride=4,
    resize=1,
    margin=14,
    factor=0.6,
    keep_all=True,
    device=device
)

DEVICE = '/dev/video0'
SIZE = (640, 480)
FILENAME = 'capture.png'

def flipimg(x):
    x = np.fliplr(x)
    x = np.rot90(x,k=1,axes=(0,1))
    return x

def snap():
    return flipimg(pygame.surfarray.array3d(camera.get_image()))


pygame.init()
pygame.camera.init()

camera = pygame.camera.Camera(DEVICE, SIZE)
camera.start()

currentRez = (pygame.display.Info().current_w, pygame.display.Info().current_h)
screen = pygame.display.set_mode(currentRez, pygame.SCALED) # print(pygame.display.Info().current_w,pygame.display.Info().current_h) #1920 1080


red   = (200,0,0)
blue  = (0,0,200)
black = (0,0,0)
white = (200,200,200)

radius = 30

w0 = 1920
h0 = 1080

offset = 75 

x = np.random.randint(offset, w0 - offset)
y = np.random.randint(offset, h0 - offset)

N = 1000

X = np.zeros((N,256,256,3))
Y = np.zeros((N,2))
 

j = 0 




capture = True
while capture:
    
    for event in pygame.event.get():
       if event.type == QUIT:
           capture = False
       elif event.type == KEYDOWN:
           if event.key == K_ESCAPE:
               capture = False
           # if event.key == K_SPACE:
               
               # pygame.image.save(screen, FILENAME)
   
    img = snap()
    boxes = fast_mtcnn(img)

    if boxes is not None: 

       i = 0

       x1,y1,x2,y2 = np.array(boxes[i]).astype(int)
       w = x2 - x1
       h = y2 - y1

       img = img[y1:y1+h,x1:x1+w]
       
       img = Image.fromarray(img).resize((256,256))
       
       X[j] = img 
       Y[j] = (x,y)

       j += 1
       
       # plot(img)


    # Image.fromarray(img).save(str(x) + "_" + str(y) + ".jpeg")

    x += np.round(np.random.normal(scale=3, size=1)[0]) #np.random.randint(-10,10)
    y += np.round(np.random.normal(scale=3, size=1)[0]) #np.random.randint(-10,10)
    
    
               
    screen.fill((0,0,0))
    pygame.draw.circle(screen,blue,(x,y),radius)
    pygame.draw.circle(screen,white,(x,y),2)
    pygame.display.update() 

    # plt.imshow(snap())
    # plt.show()

camera.stop()
pygame.quit()
    
