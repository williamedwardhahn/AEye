import pygame
import pygame.camera
from pygame.locals import *
import numpy as np
import matplotlib.pyplot as plt
import time

DEVICE = '/dev/video0'
SIZE = (640, 480)
FILENAME = 'capture.png'

def flipimg(x):
    x = np.fliplr(x)
    x = np.rot90(x,k=1,axes=(0,1))
    return x

def snap():
    return flipimg(pygame.surfarray.array3d(camera.get_image(screen)))

pygame.init()
pygame.camera.init()
display = pygame.display.set_mode(SIZE, 0)
camera = pygame.camera.Camera(DEVICE, SIZE)
camera.start()

screen = pygame.surface.Surface(SIZE, 0, display)
capture = True


while capture:


    plt.imshow(snap())
    plt.show()

    for event in pygame.event.get():
       if event.type == QUIT:
           capture = False
       elif event.type == KEYDOWN:
           if event.key == K_ESCAPE:
               capture = False
    
    
camera.stop()
pygame.quit()
    
