import pygame
import pygame.camera
from pygame.locals import *
import numpy as np
import matplotlib.pyplot as plt
import time

DEVICE = '/dev/video0'
SIZE = (640, 480)
FILENAME = 'capture.png'

circleX = 500
circleY = 500
radius = 10

red = (200,0,0)


def flipimg(x):
    x = np.fliplr(x)
    x = np.rot90(x,k=1,axes=(0,1))
    return x

def snap():
    return flipimg(pygame.surfarray.array3d(camera.get_image(screen)))

pygame.init()
pygame.camera.init()

camera = pygame.camera.Camera(DEVICE, SIZE)
camera.start()

capture = True

# display = pygame.display.set_mode(SIZE, 0)
# screen = pygame.surface.Surface(SIZE, 0, display)
# screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

currentRez = (pygame.display.Info().current_w, pygame.display.Info().current_h)
screen = pygame.display.set_mode(currentRez, pygame.SCALED)



while capture:
    
    for event in pygame.event.get():
       if event.type == QUIT:
           capture = False
       elif event.type == KEYDOWN:
           if event.key == K_ESCAPE:
               capture = False
    
    screen.fill((0,0,0))
    
    pygame.draw.circle(screen,red,(circleX,circleY),radius)
    pygame.display.update() 

    # plt.imshow(snap())
    # plt.show()

    
    
    
camera.stop()
pygame.quit()
    
